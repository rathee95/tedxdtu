<?php

defined('DB_SERVER') ? null : define('DB_SERVER','mysql.hostinger.in');
defined('DB_USER') ? null : define('DB_USER','u370679023_ankit');
defined('DB_PASS') ? null : define('DB_PASS','qKcSkm8qlA');
defined('DB_NAME') ? null : define('DB_NAME','u370679023_ted');


?>