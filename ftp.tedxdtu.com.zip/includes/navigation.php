<div id="fb-root"></div>
    <script>
    (function(d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) return;
        js = d.createElement(s);
        js.id = id;
        js.src = "//connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v2.5";
        fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'facebook-jssdk'));
    </script>

<div class="main_menu navbar-fixed">
    <div class="row">
        <div class="columns small-12 medium-12 large-12">
            <div class="mb">
                <div class="navmobile">
                    <a href="/"></a>
                </div>
                <ul id="menu-main-menu-homepage" class="menu">
                    <li id="menu-item-71" class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-2 current_page_item menu-item-71"><a href="/"><img src ="wp-content/uploads/sites/9/2014/10/logo.png"></a></li>
                    <li id="menu-item-71" class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-2 current_page_item menu-item-71"><a href="/">Home</a></li>
                    <li id="menu-item-149" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-149"><a href="/#aboutus">About TED<span style="text-transform:none;">x</span></a></li>
                    <li id="menu-item-72" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-72"><a href="/#speakers1">Past Speakers</a></li>
                    <!-- <li id="menu-item-72" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-72"><a href="http://goo.gl/forms/tU6vltl1DQ" target="_blank">Suggest A Speaker</a></li> -->
                    <!-- <li id="menu-item-134" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-134"><a href="http://blog.tedxdtu.com/" target="_blank">Blog</a></li> -->
                    <!-- <li id="menu-item-73" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-73"><a href="/#schedule">Schedule</a></li> -->
                    <!-- <li id="menu-item-74" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-74"><a href="/#sponsors">Sponsors</a></li> -->
                    <li id="menu-item-81" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-81"><a href="ourteam.php"> Our Team</a></li>
                    <!--<li id="menu-item-81" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-81"><a href="login.php"> Register</a></li>-->

                    <!-- <li id="menu-item-75" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-75"><a href="/#pricing">Buy Tickets</a></li> -->
                    <!-- <li id="menu-item-80" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-80"><a href="sponsors.php">Sponsors</a></li> -->

                    <li id="menu-item-74" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-80"><a href="partners.php" >Partner with us</a></li>

                    
                    
                            

                            
                            <!-- <li id="menu-item-122" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-122"><a href="gallery.php">Galleries</a></li> -->
                            <!-- <li id="menu-item-134" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-134"><a href="contacts.php">Contact</a></li> -->
                            
                    
                    
                    <li id="menu-item-154" class="register menu-item menu-item-type-custom menu-item-object-custom menu-item-154"><a href="http://blog.tedxdtu.com/">BLOG</a></li>
                    
                </ul>
            </div>
        </div>
    </div>
</div>
<?php if (!isset($page)): ?>
    <div class="mini_header">
        <div class="mini_header_bg " style="background-color: black"></div>
        <div class="row">
            <div class="columns small-12 medium-12 large-12" >
                <div class="logo" >
                    <h1 id="site-title" >
                        <a href="/" rel="home"><img src = "wp-content/uploads/sites/9/2014/10/logomin.png
                        "></a>
                    </h1>
                </div>
                <div class="sub-logo">
                    <h2 id="site-description">April 2016</h2>
                </div>
            </div>
        </div>
    </div>
<?php endif ?>
